package com.tnsif.SpringQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringQualifierApplicationTests {

	@Test
	void contextLoads() {
	}

}
