package com.tnsif.SpringQ;

public interface shoppingMall {
	void purchase();
}
