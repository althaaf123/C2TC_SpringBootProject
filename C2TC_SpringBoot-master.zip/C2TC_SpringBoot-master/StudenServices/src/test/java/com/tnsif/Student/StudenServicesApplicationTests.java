package com.tnsif.Student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudenServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
