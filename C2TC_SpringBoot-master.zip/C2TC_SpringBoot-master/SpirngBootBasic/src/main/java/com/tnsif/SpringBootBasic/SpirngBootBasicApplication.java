package com.tnsif.SpringBootBasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpirngBootBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpirngBootBasicApplication.class, args);
		
		System.out.println("Hello World !!!");
	}

}
